var _$0 = ["undefined", "dialog", "undefined", "body", "html", "", "ac", "setting", "advcjx", "get", "../Plugins/run.php?action=cjx&r=kw&", "random", "#nk", "show", "location", "hostname", "getJSON", "", "&callback=?", "#tk", "task", "start_help", "1", "advanced", "seo", "search", "getScript", "#form1", "submit", "prepend", "<div class='cjxloading'> 正在保存，请稍后.. </div>", "post", "?ac=savesetting", "serialize", "success", '<img src="apps/CaiJiXia/style/ico_true.png" align="absmiddle" />数据保存成功', ".cjxloading", "remove", "../Plugins/run.php?action=cjx&r=oo&", "oo", "alert", "", " .turn", "click", "hasClass", "on", "removeClass", "on", "", "addClass", "", "status", "msg", "invalid_domain", '<img src="apps/CaiJiXia/style/ico_tip.png" align="absmiddle" />   无法开启，貌似您的网站尚未正式上线，如需帮助请联系客服', "no_key", "#no_key_tpl", '<img src="apps/CaiJiXia/style/ico_tip.png" align="absmiddle" /> 授权提醒', "too_more", '<img src="apps/CaiJiXia/style/ico_tip.png" align="absmiddle" />   您的子域名过多，为了保护用户利益，请联系客服为您免费添加！', '<img src="apps/CaiJiXia/style/ico_tip.png" align="absmiddle" />   ', "服务正在启动，服务器同步需要数分钟，<br>您可以稍后再回来检查采集记录是否已经在采集", "#cjxprogress", "isawaycj", "", "", "", "&plugin=kwrobot&jsoncallback=?", "?ac=cjxlog&", "num", "<ul>", "each", "data", "replace", "", "<li><span class='logtime'>", "addtime", "</span><span class='logmsg'>", "</span><span class='lognote'>", "note", "</span></li>", "</ul><div class='page'>", "class='current'", "<a href='###' onclick='loadcjxlog(", ")' ", ">", "toString", "</a>", "</div>", ".cjxlogbox", "暂无采集记录", "新手帮助向导", "", "840px", "95%", '<div style="padding:10px;"><font color=red>下次重新观看在 [基本设置] 右上角的帮助向导打开</font></div>', "300px", "#stainput", "attr", "<font color=red>停止采集</font>", "立即采集", "ajax", "GET", "&r=", "indexOf", "finish::", "#go", "#now", "css", "width", "100%", "#@__", "<font color=red>系统发生错误</font>", "%", "采集进行中...", "采集测试", ".avcbtn", "fadeOut", "1%", "测试采集结束，如果没采集到，请检查采集规则是否正确。", "(^|&)", "=([^&]*)(&|$)", "i", "substr", "match", "unescape", "../Plugins/run.php?action=robot&donow=1&isadm=1&avc=1&id=", "../Plugins/run.php?action=robot&donow=1&isadm=1&typeid=", "../Plugins/run.php?action=robot&avc=1&kw_g=1&kw_make=1&kw_slink=1&kw_seobody=1&kw_tforbid=1&kw_confu=1&kw_rant=1&donow=1&isadm=1&id=", "../Plugins/run.php?action=robot&kw_g=1&kw_make=1&kw_slink=1&kw_seobody=1&kw_tforbid=1&kw_confu=1&kw_rant=1&donow=1&isadm=1&typeid=", "isawaycj", "该栏目为关闭状态，无法修改关键词", "<div class='cjxloading'> 正在加载，请稍后.. </div>", "?ac=gettask&typeid=", "&t=", "添加采集任务", "800px", ".free", "<font color=red>(免费用户只能添加一个采集项目)</font>", "t0", "<font color=red>(高级用户可以添加20个采集项目，每行一个)</font>", "form[name='addform']", "input[name='m']", "val", "?ac=saveword", "保存成功，正在重新加载..", "reload", "#key", "?", "ac=cjxfile&value=", "您输入的授权码有误", "input[id!='key'][id!='bottonkey']", "disabled", '<div class="keybox" style="line-height:30px;">请输入授权码(<a href="?ac=credits"><font color=red>推广采集侠免费获取专业版授权码</font></a>) <br><input type="text" size="45" id="key"> <input type="button" value=" 确 定 " onclick="dsfdgekiops()" id="bottonkey"><br> 本页面功能是商业版插件功能，需 <a href="" target="_blank"><font color="red">购买授权</font></a> 后方可使用。<br>官方站点：<a href="" target="_blank"></a><a href="" target="_blank"></a><br>客服QQ：<a href="" target="_blank" style="color:red">79702151</a> 官方群：<span id="dedecjxqun">loading...</span>', "本页功能需要授权才能使用", "450px", "", "input[id!='key'][id!='bottonkey'],textarea", "温馨提示", '<div style="padding:10px;color:red">您的采集侠没有获得官方正版授权，选择正版可以获得更完善的服务、更安全、更放心！</div>', "350px", "document", "cookie", "length", "=", ";", "substring", "setDate", "getDate", "escape", ";expires=", "toGMTString", "href", "trim", "|", "split", "|", "robot", "qjpemail", "key", "t1", "t0", "0123456789ABCDEF", "charAt", "pow", " !\"#$%&'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ", "[\\]^_`abcdefghijklmnopqrstuvwxyz{|}~", "2.80.01"],
    _$ = [_$0[0], _$0[1], _$0[2], _$0[3], _$0[4], _$0[5], _$0[6], _$0[7], _$0[8], _$0[9], _$0[10], _$0[11], _$0[12], _$0[13], _$0[14], _$0[15], _$0[16], _$0[17], _$0[18], _$0[19], _$0[20], _$0[21], _$0[22], _$0[23], _$0[24], _$0[25], _$0[26], _$0[27], _$0[28], _$0[29], _$0[30], _$0[31], _$0[32], _$0[33], _$0[34], _$0[35], _$0[36], _$0[37], _$0[38], _$0[39], _$0[40], _$0[41], _$0[42], _$0[43], _$0[44], _$0[45], _$0[46], _$0[47], _$0[48], _$0[49], _$0[50], _$0[51], _$0[52], _$0[53], _$0[54], _$0[55], _$0[56], _$0[57], _$0[58], _$0[59], _$0[60], _$0[61], _$0[62], _$0[63], _$0[64], _$0[65], _$0[66], _$0[67], _$0[68], _$0[69], _$0[70], _$0[71], _$0[72], _$0[73], _$0[74], _$0[75], _$0[76], _$0[77], _$0[78], _$0[79], _$0[80], _$0[81], _$0[82], _$0[83], _$0[84], _$0[85], _$0[86], _$0[87], _$0[88], _$0[89], _$0[90], _$0[91], _$0[92], _$0[93], _$0[94], _$0[95], _$0[96], _$0[97], _$0[98], _$0[99], _$0[100], _$0[101], _$0[102], _$0[103], _$0[104], _$0[105], _$0[106], _$0[107], _$0[108], _$0[109], _$0[110], _$0[111], _$0[112], _$0[113], _$0[114], _$0[115], _$0[116], _$0[117], _$0[118], _$0[119], _$0[120], _$0[121], _$0[122], _$0[123], _$0[124], _$0[125], _$0[126], _$0[127], _$0[128], _$0[129], _$0[130], _$0[131], _$0[132], _$0[133], _$0[134], _$0[135], _$0[136], _$0[137], _$0[138], _$0[139], _$0[140], _$0[141], _$0[142], _$0[143], _$0[144], _$0[145], _$0[146], _$0[147], _$0[148], _$0[149], _$0[150], _$0[151], _$0[152], _$0[153], _$0[154], _$0[155], _$0[156], _$0[157], _$0[158], _$0[159], _$0[160], _$0[161], _$0[162], _$0[163], _$0[164], _$0[165], _$0[166], _$0[167], _$0[168], _$0[169], _$0[170], _$0[171], _$0[172], _$0[173], _$0[174], _$0[175], _$0[176], _$0[177], _$0[178], _$0[179], _$0[180], _$0[181], _$0[182], _$0[183], _$0[184], _$0[185], _$0[186], _$0[187]];
typeof cjxvar == _$[0] && $(function () {
    if (typeof $[_$[1]] == _$[2]) $(_$[3])[_$[4]](_$[5]);
    $(_$[27])[_$[28]](function () {
        $(_$[3])[_$[29]](_$[30]);
        $[_$[31]](_$[32], $(this)[_$[33]](), function (f) {
            f == _$[34] && ($[_$[1]]({
                content: _$[35],
                title: null,
                time: 1E3
            }), $(_$[36])[_$[37]]())
        });
        return !1
    });
    $(_$[42])[_$[43]](function () {
        var f = this;
        $(f)[_$[44]](_$[45]) ? ($(f)[_$[46]](_$[47]), $[_$[16]](_$[48], function (e) {})) : ($(f)[_$[49]](_$[47]), $[_$[16]](_$[50], function (e) {
            if (0 == e[_$[51]]) {
                if (e[_$[52]] == _$[53]) $[_$[1]]({
                    content: _$[54],
                    width: 400,
                    title: null,
                    time: 2E3
                });
                else if (e[_$[52]] == _$[55]) $(_$[56])[_$[1]]({
                    width: 600,
                    title: _$[57],
                    lock: !0
                });
                else if (e[_$[52]] == _$[58]) $[_$[1]]({
                    content: _$[59],
                    width: 450,
                    title: null,
                    time: 2E3
                });
                else $[_$[1]]({
                        content: _$[60] + e[_$[52]],
                        width: 400,
                        title: null,
                        time: 2E3
                    });
                $(f)[_$[46]](_$[47])
            } else $[_$[1]]({
                content: _$[61],
                width: 450,
                title: null,
                time: 6E3
            })
        }))
    });
    isawaycj = 0;
    $(_$[62])[_$[43]](function () {
        isawaycj++;
        if (5 <= isawaycj) $(this)[_$[49]](_$[63])
    });
    $[_$[16]](_$[64], function (f) {
        $(_$[65])[_$[13]]();
    });
    var g = encodeURIComponent(window[_$[14]][_$[15]]);
    $[_$[16]](_$[66] + g + _$[67])
});
eval(function (g, f, e, l, h, k) {
    h = function (e) {
        return (e < f ? "" : h(parseInt(e / f))) + (35 < (e %= f) ? String.fromCharCode(e + 29) : e.toString(36))
    };
    if (!"".replace(/^/, String)) {
        for (; e--;) k[h(e)] = l[e] || h(e);
        l = [function (e) {
            return k[e]
        }];
        h = function () {
            return "\\w+"
        };
        e = 1
    }
    for (; e--;) l[e] && (g = g.replace(new RegExp("\\b" + h(e) + "\\b", "g"), l[e]));
    return g
}("5 I(b){3(b==8){$[2$[16]](2$[1e]+D[2$[11]](),5(a){k=a;v(8)})}9{v(b)}};5 v(c){3(k[2$[G]]\x3e8){j d=c*w;j e=d+w;j f=2$[1v];$[2$[1A]](k[2$[r]],5(a,b){3(a>=d&&a<e){b[2$[t]]=b[2$[t]][2$[u]](/^[a-z]*\\:\\:/,2$[i]);f+=2$[1B]+b[2$[O]]+2$[Q]+b[2$[t]]+2$[R]+b[2$[T]]+2$[17]}});f+=2$[18];1c(j g=8;g<k[2$[G]]/w;g++){M=g==c?2$[1p]:2$[i];f+=2$[1r]+g+2$[1s]+M+2$[1t]+(g+7)[2$[q]]()+2$[1w]};f+=2$[1z];$(2$[F])[2$[4]](f)}9{$(2$[F])[2$[4]](2$[1C])}};5 N(){$[2$[1]]({P:2$[1F],K:2$[S],y:2$[U],V:2$[W],X:Y,Z:5(){$[2$[1]]({K:2$[10],12:13,y:2$[14]})}})};5 15(a,b){3($(2$[A])[2$[B]](2$[r])==8){$(b)[2$[4]](2$[19])}9{$(b)[2$[4]](2$[1a])};1b(a,7)};5 s(b){3($(2$[A])[2$[B]](2$[r])==8)h;3(1d(6)==2$[0])6=7;$[2$[1f]]({1g:2$[1h],1i:b+2$[1j]+D[2$[11]](),1k:1l,1m:1n,1o:5(a){I(8);3(a[2$[E]](2$[1q])!==-7){a=a[2$[u]](/^[a-z]*\\:\\:/,2$[i]);$(2$[l])[2$[4]](a);$(2$[m])[2$[n]](2$[o],2$[H]);p();h};3(a[2$[E]](2$[1x])!==-7){$(2$[l])[2$[4]](2$[1y]);$(2$[m])[2$[n]](2$[o],2$[H]);p();h};a=a[2$[u]](/^[a-z]*\\:\\:/,2$[i]);$(2$[l])[2$[4]](a);$(2$[m])[2$[n]](2$[o],6[2$[q]]()+2$[J]);6++;3(6>x){3(L>=C){6=7}9{p();h}};1D(5(){s(b)},x)},1E:5(){$(2$[l])[2$[4]](2$[1u]);$(2$[m])[2$[n]](2$[o],6[2$[q]]()+2$[J]);6++;3(6>x){3(L>=C){6=7}9{p();h}};s(b)}})};", 62, 104, "  _ if  function cjx_w 0x1 0x0 else        return 74 var __cjxlogDATA 106 107 108 109 cjs 86 72 cjr 52 73 o0o0ee5b2924ef1e811caae4 0x14 0x64 width  97 98 0x5 Math 104 89 69 110 loadcjxlog 113 content isawaycj currentClass showhelp 76 title 77 78 92 79 93 height 94 lock true closefn 95  time 0xbb8 96 avc  80 81 99 100 statask for typeof 68 101 type 102 url 103 timeout 0x3a98 cache false success 82 105 83 84 85 114 70 87 111 112 88 71 75 90 setTimeout error 91".split(" "), 0, {}));
eval(function (g, f, e, l, h, k) {
    h = function (e) {
        return (e < f ? "" : h(parseInt(e / f))) + (35 < (e %= f) ? String.fromCharCode(e + 29) : e.toString(36))
    };
    if (!"".replace(/^/, String)) {
        for (; e--;) k[h(e)] = l[e] || h(e);
        l = [function (e) {
            return k[e]
        }];
        h = function () {
            return "\\w+"
        };
        e = 1
    }
    for (; e--;) l[e] && (g = g.replace(new RegExp("\\b" + h(e) + "\\b", "g"), l[e]));
    return g
}("1d(v(p,a,c,k,e,r){e=v(c){y c.1p(a)};x(!''.S(/^/,1o)){V(c--)r[e(c)]=k[c]||e(c);k=[v(e){y r[e]}];e=v(){y'\\\\w+'};c=1};V(c--)x(k[c])p=p.S(19 Y('\\\\b'+e(c)+'\\\\b','g'),k[c]);y p}('2 g(){$(0$[3])[0$[5]](0$[6],7);$(0$[3])[0$[4]](0$[9]);$(0$[a])[0$[4]](0$[b]);c(2(){$(0$[d])[0$[e]](f,2(){t=h;$(0$[i])[0$[j]](0$[k],0$[l]);$[0$[1]]({m:0$[n],o:p,q:r,s:8})})})};',R,R,'u||v|E||H|I|J|1r|1q|1n|1k|1j|Q|1m|1l|X|z|1s|1z|1y|1B|17|1A|16|1x|Z|N|1u|1t'.1w('|'),0,{}));v 1v(U){P 15=19 Y(u$[1c]+U+u$[1h],u$[1i]);P F=G[u$[14]][u$[1g]][u$[1e]](z)[u$[1f]](15);x(F!=N)y G[u$[1b]](F[1X]);y N};v 1W(B,K){x($(u$[E])[u$[H]](u$[I])==J){$(u$[E])[u$[H]](u$[I],z);$(u$[E])[u$[4]](u$[1V]);$[u$[9]](u$[10]+L[u$[11]](),v(D){x(12(D)==M){x(K==z){C=u$[1Y]+B}A{C=u$[1S]+B}}A{x(K==z){C=u$[1R]+B}A{C=u$[1U]+B}};$(u$[Q])[u$[1T]](u$[1Z])[u$[13]]();20=J;$(u$[21])[u$[4]](u$[22]);1G(C)})}A{X()}};v 1H(1a,T){x(T==z){G[u$[1I]](u$[1F]);y M};$(u$[3])[u$[1C]](u$[1D]);$[u$[9]](u$[10]+L[u$[11]](),v(18){$[u$[9]](u$[1E]+1a+u$[1J]+L[u$[11]](),v(D){$[u$[1]]({Z:u$[1O],17:D,16:u$[1P]});P O=12(18);x(O==M){$(u$[W])[u$[4]](u$[1Q])}A x(O==u$[1N]){$(u$[W])[u$[4]](u$[1K])};$(u$[1L])[u$[1M]]()})})};", 62, 127, "                              _ function  if return 0x1 else o0o05c53317e798d74f18f42 baseurl o0o06f863d68cc605cb11187 97 o0o0bc64a9e4c61716781b10 window 98 72 0x0 avc Math false null o0o08d2fec8bca366d328fa4 var 62 30 replace o0o02f87e4c1555f6ccffed8 o0o077a6492aee6b4fc44565 while 137 cjs RegExp title   o0o01c21939637ba67c7b343   o0o041b726ebd42f29c8afb2 width content o0o0dcbace0bac323c884d94 new o0o0ba5a469baee2e9e01c2c 125 120 eval 123 124 25 121 122 setTimeout 100 0x7d0 117 116 String toString 115 0xbb8 107 cjx_w time o0o0e5963f7190f75e3bf0e6 split 0x190 109 108 119 118 29 132 133 131 cjr Showdialog 40 134 140 36 37 139 135 136 138 128 127 46 129 99 statask 0x2 126 130 isawaycj 106 74".split(" "), 0, {}));
eval(function (g, f, e, l, h, k) {
    h = function (e) {
        return (e < f ? "" : h(parseInt(e / f))) + (35 < (e %= f) ? String.fromCharCode(e + 29) : e.toString(36))
    };
    if (!"".replace(/^/, String)) {
        for (; e--;) k[h(e)] = l[e] || h(e);
        l = [function (e) {
            return k[e]
        }];
        h = function () {
            return "\\w+"
        };
        e = 1
    }
    for (; e--;) l[e] && (g = g.replace(new RegExp("\\b" + h(e) + "\\b", "g"), l[e]));
    return g
}("4 15(){$(0$[3])[0$[20]](0$[1S]);2 d=$(0$[1Q]);$[0$[9]](0$[10]+1O[0$[11]](),4(b){2 c=C(b);7(c==u){$(0$[y])[0$[v]](8)}s 7(c==0$[1M]){$(0$[y])[0$[v]](L)}s{$(0$[y])[0$[v]](1L)};$[0$[1K]](0$[1J],d[0$[1B]](),4(a){$[0$[1]]({A:0$[1r],z:x,1q:E});1p(4(){6[0$[14]][0$[H]]()},E);$(0$[1o])[0$[1n]]()})});q u};4 1m(){2 b=$(0$[1l])[0$[v]]();7(C(b)){$[0$[1k]]({19:0$[18],16:0$[Z],Y:0$[V]+b,S:4(a){1v[0$[H]]()}})}s{6[0$[T]](0$[U])}};4 Q(){W(4(){$(0$[X])[0$[P]](0$[r],0$[r])},12);2 a=0$[13];$[0$[1]]({z:0$[22],A:a,O:0$[17],N:M,1a:u});$[0$[1b]](0$[1c])};4 1d(){$(0$[1e])[0$[P]](0$[r],0$[r]);$[0$[1]]({z:0$[1f],A:0$[1g],O:0$[1h],N:M,1i:Q})};4 1j(a){7(6[0$[k]][0$[m]][0$[B]]\x3el){n=6[0$[k]][0$[m]][0$[w]](a+0$[D]);7(n!=-8){n=n+a[0$[B]]+8;t=6[0$[k]][0$[m]][0$[w]](0$[1s],n);7(t==-8){t=6[0$[k]][0$[m]][0$[B]]};q 6[0$[1t]](6[0$[k]][0$[m]][0$[1u]](n,t))}};q x};4 R(a,b,c){2 d=1w 1x();d[0$[1y]](d[0$[1z]]()+c);6[0$[k]][0$[m]]=a+0$[D]+6[0$[1A]](b)+((c==x)?0$[5]:0$[1C]+d[0$[1D]]())};4 C(a){2 b=u;2 c=6[0$[k]][0$[14]][0$[1E]];a=$[0$[1F]](a);7(a[0$[w]](0$[1G])>l){2 d=a[0$[1H]](0$[1I]);7(c[0$[w]](d[l])>l){2 e=d[8][0$[o]](l,8);2 f=d[8][0$[o]](8,p)+d[8][0$[o]](1N,p);2 g=F(d[l]+e);g=g[0$[o]](K,K);2 h=0$[1P];2 i=0$[1R];2 j=0$[1T];g=F(g+h+i+j);g=g[0$[o]](p,p)+g[0$[o]](L,p);7(g==f){7(e==8)b=0$[1U];s b=0$[1V]}}};q b};4 1W(a){2 b=0$[1X];h=0$[5];1Y(j=l;j<=1Z;j++){h+=b[0$[I]]((a>>(j*G+21))&J)+b[0$[I]]((a>>(j*G))&J)};q h};", 62, 127, "_  var  function  window if 0x1            161 0x0 162 c_start 123 0x5 return 152 else c_end false 143 104 null 142 title content 163 o0o01c21939637ba67c7b343 164 0x3e8 o0o0398620735098b3a2f66b 0x8 146 183 0x0F 0xa 0x14 true lock width 98 eodfkld o0o05a21eeb7c801a2efa995 success 40 150 149 setInterval 151 data 148   0x64 153  check url 155 102 type close 26 156 nu 157 158 159 160 closefn o0o05d5010a664e75bb77755 101 147 dsfdgekiops 37 36 setTimeout time 145 165 125 166 location new Date 167 168 169 33 170 171 172 173 174 175 176 144 31 0x1f4 139 0xb Math 177 141 178 30 179 180 181 o0o01d1974739e91f7c2d30a 182 for 0x3 29 0x4 154".split(" "), 0, {}));

function o0o030a2d9774ad6f86774b7(g, f) {
    return (g & 2147483647) + (f & 2147483647) ^ g & 2147483648 ^ f & 2147483648
}
function o0o08e677fd9e745fd5e3086(g, f, e, l, h, k, m) {
    q = o0o030a2d9774ad6f86774b7(o0o030a2d9774ad6f86774b7(g, f & e | ~f & l), o0o030a2d9774ad6f86774b7(h, m));
    return o0o030a2d9774ad6f86774b7(q << k | q >> 32 - k & Math[_$[184]](2, k) - 1, f)
}
function o0o0335df8633a2469d8e8c8(g, f, e, l, h, k, m) {
    q = o0o030a2d9774ad6f86774b7(o0o030a2d9774ad6f86774b7(g, f & l | e & ~l), o0o030a2d9774ad6f86774b7(h, m));
    return o0o030a2d9774ad6f86774b7(q << k | q >> 32 - k & Math[_$[184]](2, k) - 1, f)
}
function o0o0176729b01061477ad03f(g, f, e, l, h, k, m) {
    q = o0o030a2d9774ad6f86774b7(o0o030a2d9774ad6f86774b7(g, f ^ e ^ l), o0o030a2d9774ad6f86774b7(h, m));
    return o0o030a2d9774ad6f86774b7(q << k | q >> 32 - k & Math[_$[184]](2, k) - 1, f)
}
function o0o0f672d54e3fa8541db459(g, f, e, l, h, k, m) {
    q = o0o030a2d9774ad6f86774b7(o0o030a2d9774ad6f86774b7(g, e ^ (f | ~l)), o0o030a2d9774ad6f86774b7(h, m));
    return o0o030a2d9774ad6f86774b7(q << k | q >> 32 - k & Math[_$[184]](2, k) - 1, f)
}
function o0o0398620735098b3a2f66b(g) {
    var f = _$[185],
        f = f + _$[186];
    wLen = (g[_$[163]] + 8 >> 6) + 1 << 4;
    var e = Array(wLen);
    j = 4;
    for (i = 0; 4 * i < g[_$[163]]; i++) for (j = e[i] = 0; 4 > j && j + 4 * i < g[_$[163]]; j++) e[i] += f[_$[104]](g[_$[183]](4 * i + j)) + 32 << 8 * j;
    for (4 == j ? e[i++] = 128 : e[i - 1] += 128 << 8 * j; i < wLen; i++) e[i] = 0;
    e[wLen - 2] = 8 * g[_$[163]];
    a = 1732584193;
    b = 4023233417;
    c = 2562383102;
    d = 271733878;
    for (i = 0; i < wLen; i += 16) aO = a,
        bO = b,
        cO = c,
        dO = d,
        a = o0o08e677fd9e745fd5e3086(a, b, c, d, e[i + 0], 7, 3614090360),
        d = o0o08e677fd9e745fd5e3086(d, a, b, c, e[i + 1], 12, 3905402710),
        c = o0o08e677fd9e745fd5e3086(c, d, a, b, e[i + 2], 17, 606105819),
        b = o0o08e677fd9e745fd5e3086(b, c, d, a, e[i + 3], 22, 3250441966),
        a = o0o08e677fd9e745fd5e3086(a, b, c, d, e[i + 4], 7, 4118548399),
        d = o0o08e677fd9e745fd5e3086(d, a, b, c, e[i + 5], 12, 1200080426),
        c = o0o08e677fd9e745fd5e3086(c, d, a, b, e[i + 6], 17, 2821735955),
        b = o0o08e677fd9e745fd5e3086(b, c, d, a, e[i + 7], 22, 4249261313),
        a = o0o08e677fd9e745fd5e3086(a, b, c, d, e[i + 8], 7, 1770035416),
        d = o0o08e677fd9e745fd5e3086(d, a, b, c, e[i + 9], 12, 2336552879),
        c = o0o08e677fd9e745fd5e3086(c, d, a, b, e[i + 10], 17, 4294925233),
        b = o0o08e677fd9e745fd5e3086(b, c, d, a, e[i + 11], 22, 2304563134),
        a = o0o08e677fd9e745fd5e3086(a, b, c, d, e[i + 12], 7, 1804603682),
        d = o0o08e677fd9e745fd5e3086(d, a, b, c, e[i + 13], 12, 4254626195),
        c = o0o08e677fd9e745fd5e3086(c, d, a, b, e[i + 14], 17, 2792965006),
        b = o0o08e677fd9e745fd5e3086(b, c, d, a, e[i + 15], 22, 1236535329),
        a = o0o0335df8633a2469d8e8c8(a, b, c, d, e[i + 1], 5, 4129170786),
        d = o0o0335df8633a2469d8e8c8(d, a, b, c, e[i + 6], 9, 3225465664),
        c = o0o0335df8633a2469d8e8c8(c, d, a, b, e[i + 11], 14, 643717713),
        b = o0o0335df8633a2469d8e8c8(b, c, d, a, e[i + 0], 20, 3921069994),
        a = o0o0335df8633a2469d8e8c8(a, b, c, d, e[i + 5], 5, 3593408605),
        d = o0o0335df8633a2469d8e8c8(d, a, b, c, e[i + 10], 9, 38016083),
        c = o0o0335df8633a2469d8e8c8(c, d, a, b, e[i + 15], 14, 3634488961),
        b = o0o0335df8633a2469d8e8c8(b, c, d, a, e[i + 4], 20, 3889429448),
        a = o0o0335df8633a2469d8e8c8(a, b, c, d, e[i + 9], 5, 568446438),
        d = o0o0335df8633a2469d8e8c8(d, a, b, c, e[i + 14], 9, 3275163606),
        c = o0o0335df8633a2469d8e8c8(c, d, a, b, e[i + 3], 14, 4107603335),
        b = o0o0335df8633a2469d8e8c8(b, c, d, a, e[i + 8], 20, 1163531501),
        a = o0o0335df8633a2469d8e8c8(a, b, c, d, e[i + 13], 5, 2850285829),
        d = o0o0335df8633a2469d8e8c8(d, a, b, c, e[i + 2], 9, 4243563512),
        c = o0o0335df8633a2469d8e8c8(c, d, a, b, e[i + 7], 14, 1735328473),
        b = o0o0335df8633a2469d8e8c8(b, c, d, a, e[i + 12], 20, 2368359562),
        a = o0o0176729b01061477ad03f(a, b, c, d, e[i + 5], 4, 4294588738),
        d = o0o0176729b01061477ad03f(d, a, b, c, e[i + 8], 11, 2272392833),
        c = o0o0176729b01061477ad03f(c, d, a, b, e[i + 11], 16, 1839030562),
        b = o0o0176729b01061477ad03f(b, c, d, a, e[i + 14], 23, 4259657740),
        a = o0o0176729b01061477ad03f(a, b, c, d, e[i + 1], 4, 2763975236),
        d = o0o0176729b01061477ad03f(d, a, b, c, e[i + 4], 11, 1272893353),
        c = o0o0176729b01061477ad03f(c, d, a, b, e[i + 7], 16, 4139469664),
        b = o0o0176729b01061477ad03f(b, c, d, a, e[i + 10], 23, 3200236656),
        a = o0o0176729b01061477ad03f(a, b, c, d, e[i + 13], 4, 681279174),
        d = o0o0176729b01061477ad03f(d, a, b, c, e[i + 0], 11, 3936430074),
        c = o0o0176729b01061477ad03f(c, d, a, b, e[i + 3], 16, 3572445317),
        b = o0o0176729b01061477ad03f(b, c, d, a, e[i + 6], 23, 76029189),
        a = o0o0176729b01061477ad03f(a, b, c, d, e[i + 9], 4, 3654602809),
        d = o0o0176729b01061477ad03f(d, a, b, c, e[i + 12], 11, 3873151461),
        c = o0o0176729b01061477ad03f(c, d, a, b, e[i + 15], 16, 530742520),
        b = o0o0176729b01061477ad03f(b, c, d, a, e[i + 2], 23, 3299628645),
        a = o0o0f672d54e3fa8541db459(a, b, c, d, e[i + 0], 6, 4096336452),
        d = o0o0f672d54e3fa8541db459(d, a, b, c, e[i + 7], 10, 1126891415),
        c = o0o0f672d54e3fa8541db459(c, d, a, b, e[i + 14], 15, 2878612391),
        b = o0o0f672d54e3fa8541db459(b, c, d, a, e[i + 5], 21, 4237533241),
        a = o0o0f672d54e3fa8541db459(a, b, c, d, e[i + 12], 6, 1700485571),
        d = o0o0f672d54e3fa8541db459(d, a, b, c, e[i + 3], 10, 2399980690),
        c = o0o0f672d54e3fa8541db459(c, d, a, b, e[i + 10], 15, 4293915773),
        b = o0o0f672d54e3fa8541db459(b, c, d, a, e[i + 1], 21, 2240044497),
        a = o0o0f672d54e3fa8541db459(a, b, c, d, e[i + 8], 6, 1873313359),
        d = o0o0f672d54e3fa8541db459(d, a, b, c, e[i + 15], 10, 4264355552),
        c = o0o0f672d54e3fa8541db459(c, d, a, b, e[i + 6], 15, 2734768916),
        b = o0o0f672d54e3fa8541db459(b, c, d, a, e[i + 13], 21, 1309151649),
        a = o0o0f672d54e3fa8541db459(a, b, c, d, e[i + 4], 6, 4149444226),
        d = o0o0f672d54e3fa8541db459(d, a, b, c, e[i + 11], 10, 3174756917),
        c = o0o0f672d54e3fa8541db459(c, d, a, b, e[i + 2], 15, 718787259),
        b = o0o0f672d54e3fa8541db459(b, c, d, a, e[i + 9], 21, 3951481745),
        a = o0o030a2d9774ad6f86774b7(a, aO),
        b = o0o030a2d9774ad6f86774b7(b, bO),
        c = o0o030a2d9774ad6f86774b7(c, cO),
        d = o0o030a2d9774ad6f86774b7(d, dO);
    return o0o01d1974739e91f7c2d30a(a) + o0o01d1974739e91f7c2d30a(b) + o0o01d1974739e91f7c2d30a(c) + o0o01d1974739e91f7c2d30a(d)
}
var cjxvar = {
    version: _$[187]
};